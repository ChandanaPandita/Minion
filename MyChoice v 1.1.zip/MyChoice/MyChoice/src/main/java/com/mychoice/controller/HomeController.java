package com.mychoice.controller;

import java.security.Principal;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.mychoice.model.Item;
import com.mychoice.model.UserModel;
import com.mychoice.service.UserService;

@Controller
public class HomeController {
	@Autowired
	UserService userservice;
//mapping i.e, to the home page
	@RequestMapping("/")
	public ModelAndView onHomeLoad(){
	System.out.println("home() method called");
	return new ModelAndView("home");
	}
	//navigates to the signup page
	@RequestMapping("/signUp")
	public ModelAndView signUp(){
		UserModel usermodel=new UserModel();
	System.out.println("signUp() method called");
	return new ModelAndView("signUp","usermodelobj",usermodel);
	}
	@RequestMapping("/CustomerCheck")
	public ModelAndView customerCheck ()
	{
		return new ModelAndView("customerHome");
	
	}
	@RequestMapping("/AdminCheck")
	public ModelAndView adminCheck ()
	{
		
		return new ModelAndView("adminHome");
	
	}
	@RequestMapping("/login")
	public String loginMethod()
	{
		return "login";
	}

	@RequestMapping("/logout")
	public String logout(HttpServletRequest request)
	{
		request.getSession().invalidate();
		System.out.println("logout page called");

		return "logout";
		
	}
	
	
	//stores the values in the signup page
	@RequestMapping("/register")
	public ModelAndView register(@Valid@ModelAttribute("usermodelobj")
	UserModel user,BindingResult bindingResult)
	{
		if(bindingResult.hasErrors()){
			return new ModelAndView("signUp");
		}
		
	System.out.println("USERNAME:"+user.getName());
	System.out.println("PASSWORD:"+user.getPassword());
	userservice.addUserModel(user);
	System.out.println("Saved the details");
	return new ModelAndView("signUp");
	}
	@RequestMapping("/item")
	public ModelAndView item(@Valid@ModelAttribute("itemobj")
	Item item,BindingResult bindingResult)
	{
		if(bindingResult.hasErrors()){
			return new ModelAndView("item");
		}
		
		return new ModelAndView("item");
		}
	}
	

