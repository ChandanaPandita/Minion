package com.mychoice.service;

import org.springframework.beans.factory.annotation.Autowired;

import com.mychoice.dao.CategoryDAO;
import com.mychoice.model.Item;

public class CategoryServiceImpl implements CategoryService {
	
	
	@Autowired
	CategoryDAO categoryDAO;;
	public void addItem(Item item) {
		categoryDAO.addItem(item);
		
	}

}
