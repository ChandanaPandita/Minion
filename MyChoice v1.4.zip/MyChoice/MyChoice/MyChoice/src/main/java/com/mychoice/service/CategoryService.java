package com.mychoice.service;

import com.mychoice.model.Item;

public interface CategoryService {
	void addItem(Item item);

}
