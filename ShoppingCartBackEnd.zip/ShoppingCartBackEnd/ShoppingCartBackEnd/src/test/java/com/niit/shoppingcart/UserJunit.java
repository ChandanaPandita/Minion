package com.niit.shoppingcart;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.shoppingcart.dao.UserDAO;
import com.niit.shoppingcart.model.User;

public class UserJunit {

	@Autowired
	User user;
	
	@Autowired
	UserDAO userDAO;
	

	static AnnotationConfigApplicationContext config;
	
	@Before
	
	public void initial()
	{
		config= new AnnotationConfigApplicationContext();
		config.scan("com.niit");
		config.refresh();
		user= (User) config.getBean("user");
		userDAO = (UserDAO) config.getBean("userDAO");
		
	}
	@Test
	public void UsersizeTest()
	{
	int size=userDAO.list().size();
	assertEquals("user size is ", 3,size);
	}

	@Test
	public void UserGetTest()
	{
		user = userDAO.get("CG120");
		String id = user.getId();
		assertEquals("user id is", "CG120",id);
	}
	
	@Test
	public void UserdeleteTest()
	{
		userDAO.delete("CG140");
		
	}
	@Test
	public void UserSaveorupdateTest()
	{
		user.setId("CG143");
	    user.setName("CGName120");
		user.setAddress("address");
		userDAO.saveOrUpdate(user);
		
	}



}

