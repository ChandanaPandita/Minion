package com.niit.shoppingcart;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.shoppingcart.dao.SupplierDAO;
import com.niit.shoppingcart.model.Supplier;

public class SupplierJunit {

	@Autowired
	Supplier supplier;
	
	@Autowired
	SupplierDAO supplierDAO;
	

	static AnnotationConfigApplicationContext config;
	
	@Before
	
	public void initial()
	{
		config= new AnnotationConfigApplicationContext();
		config.scan("com.niit");
		config.refresh();
		supplier= (Supplier) config.getBean("supplier");
		supplierDAO = (SupplierDAO) config.getBean("supplierDAO");
		
	}
	@Test
	public void SuppliersizeTest()
	{
	int size=supplierDAO.list().size();
	assertEquals("supplier size is ", 3,size);
	}

	@Test
	public void SupplierGetTest()
	{
		supplier = supplierDAO.get("CG120");
		String id = supplier.getId();
		assertEquals("supplier id is", "CG120",id);
	}
	
	@Test
	public void SupplierdeleteTest()
	{
		supplierDAO.delete("CG140");
		
	}
	@Test
	public void SupplierSaveorupdateTest()
	{
		supplier.setId("CG143");
	    supplier.setName("CGName120");
		supplier.setAddress("SAddress");
		supplierDAO.saveOrUpdate(supplier);
		
	}



}

