package com.niit.shoppingcart;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.shoppingcart.dao.ProductDAO;
import com.niit.shoppingcart.model.Product;

public class ProductJunit {

	@Autowired
	Product product;
	
	@Autowired
	ProductDAO productDAO;
	

	static AnnotationConfigApplicationContext config;
	
	@Before
	
	public void initial()
	{
		config= new AnnotationConfigApplicationContext();
		config.scan("com.niit");
		config.refresh();
		product= (Product) config.getBean("product");
		productDAO = (ProductDAO) config.getBean("productDAO");
		
	}
	@Test
	public void ProductsizeTest()
	{
	int size=productDAO.list().size();
	assertEquals("product size is ", 3,size);
	}

	@Test
	public void ProductGetTest()
	{
		product = productDAO.get("CG120");
		String id = product.getId();
		assertEquals("product id is", "CG120",id);
	}
	
	@Test
	public void ProductdeleteTest()
	{
		productDAO.delete("CG140");
		
	}
	@Test
	public void ProductSaveorupdateTest()
	{
		product.setId("CG143");
	    product.setName("CGName120");
		product.setDescription("CGDesc120");
		productDAO.saveOrUpdate(product);
		
	}



}
