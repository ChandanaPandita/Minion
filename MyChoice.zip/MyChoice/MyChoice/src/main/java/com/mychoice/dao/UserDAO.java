package com.mychoice.dao;

import com.mychoice.model.UserModel;

public interface UserDAO {
	void addUserModel(UserModel user);

}
