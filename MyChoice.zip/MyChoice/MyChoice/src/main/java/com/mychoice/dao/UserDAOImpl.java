package com.mychoice.dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.mychoice.model.UserModel;
@Repository
public class UserDAOImpl implements UserDAO {
    @Autowired
	SessionFactory sessionFactory;
    //saving the entry of the customer details
	public void addUserModel(UserModel user){
		Session session=sessionFactory.getCurrentSession();
		Transaction transaction=session.beginTransaction();
		session.save(user);
		transaction.commit();
		System.out.println("Details have been saved");
	}
}
