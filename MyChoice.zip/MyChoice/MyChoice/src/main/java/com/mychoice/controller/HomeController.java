package com.mychoice.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.mychoice.model.UserModel;
import com.mychoice.service.UserService;

@Controller
public class HomeController {
	@Autowired
	UserService userservice;
//mapping i.e, to the home page
	@RequestMapping("/")
	public ModelAndView onHomeLoad(){
	System.out.println("home() method called");
	return new ModelAndView("home");
	}
	//navigating to the signin page when clicked
	@RequestMapping("/signIn")
	public ModelAndView signIn(){
	System.out.println("signIn() method called");
	return new ModelAndView("signIn");
	}
	//navigates to the signup page
	@RequestMapping("/signUp")
	public ModelAndView signUp(){
		UserModel usermodel=new UserModel();
	System.out.println("signUp() method called");
	return new ModelAndView("signUp","usermodelobj",usermodel);
	}
	//stores the values in the signup page
	@RequestMapping("/register")
	public ModelAndView register(@Valid@ModelAttribute("usermodelobj")
	UserModel user,BindingResult bindingResult)
	{
		if(bindingResult.hasErrors()){
			return new ModelAndView("signUp");
		}
		
	System.out.println("USERNAME:"+user.getName());
	System.out.println("PASSWORD:"+user.getPassword());
	userservice.addUserModel(user);
	System.out.println("Saved the details");
	return new ModelAndView("signUp");
	}
	
}
