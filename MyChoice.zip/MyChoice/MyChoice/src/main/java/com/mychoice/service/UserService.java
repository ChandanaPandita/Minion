package com.mychoice.service;


import com.mychoice.model.UserModel;

public interface UserService {

		public void addUserModel(UserModel user);

}
