package com.niit.controller;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.google.gson.Gson;
import com.niit.model.Forum;
import com.niit.model.User;
import com.niit.service.ForumService;
import com.niit.service.UserService;

@Controller
public class ForumController {
	ModelAndView mv;
	@Autowired
	private ForumService fservice;
	@Autowired
	UserService userService;

	@RequestMapping("/newforum")
	public ModelAndView createForum()
	{
		
		System.out.println("In Forum Controller");
		mv = new ModelAndView("Forum","ForumKey",new Forum());
		return mv;
	}
	
	@ModelAttribute("forum")
	public Forum returnForum()
	{
		return new Forum();
	}

	@RequestMapping("/postF")
	public String postForum(@ModelAttribute("forum") Forum forum ,BindingResult br)
	{
		System.out.println("inside add forum");
		if(br.hasErrors())
		{
			System.out.println("It has errors");
			return null;
		}
		String activeUserName = SecurityContextHolder.getContext().getAuthentication().getName();
		User user = userService.getUserByname(activeUserName);
		Date date = new Date();
		forum.setCreationdatetime(date);
		forum.setForumUserName(activeUserName);
		System.out.println("before forum save");
		fservice.createNewForum(forum);
		System.out.println("after forum save");
		return "redirect:/newforum";
	}
	@SuppressWarnings("unchecked")
	@RequestMapping("/GsonCon1")
	public @ResponseBody String getValuesForum() throws Exception
	{
		List<Forum> flist;
		String result="";
		flist = fservice.getForum();
		Gson gson = new Gson();
		result = gson.toJson(flist);
		System.out.println("before flist");
		System.out.println(flist);
		return result;
	}

}