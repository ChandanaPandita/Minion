package com.niit.controller;

import java.io.File;
import java.io.IOException;
import java.security.Principal;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.niit.model.User;
import com.niit.service.UserService;

@Controller
public class HomeController {
	@Autowired
	UserService userservice;
	ModelAndView mv;
	@RequestMapping("/")
	public ModelAndView home()
	{
		System.out.println("home page invoked");
		return new ModelAndView("home");
	}
	@RequestMapping("/login")
	public ModelAndView loginMethod()
	{
		System.out.println("inside login mapping");
		mv = new ModelAndView("login");
		return mv;
	}

	@RequestMapping("/signUp")
	public ModelAndView signUp()
	{
		System.out.println("signUp() page called");
		return new ModelAndView("signup","userobj",new User());
	}
	@RequestMapping("/homeAf")
	   public ModelAndView HomePageapp()
	  {
		  mv = new  ModelAndView("homePageAfterLogin");
		  return mv;
	  }
	@RequestMapping("/logout")
	public ModelAndView logoutMethod(HttpServletRequest request)
	{
		request.getSession().invalidate();
		System.out.println("logout called");
		mv = new ModelAndView("logout");
		return mv;
	}


	@RequestMapping("/CustomerLogin")
	public ModelAndView customerLogin(Principal principal)
	{
		System.out.println("before principal");
		System.out.println("username: "+principal.getName());
		return new ModelAndView("homePageAfterLogin");
	}
	@RequestMapping("/register")
	public String createUser(@ModelAttribute("userobj") User user , Model model,MultipartFile file) throws IOException
	{
		
		String filename = null;
	    byte[] bytes;
	    
	    		user.setRole("ROLE_USER");
	    		user.setEnabled(true);
	            userservice.saveOrUpdate(user);
	    		System.out.println("Data inserted and was saved");
	            //String path = request.getSession().getServletContext().getRealPath("/resources/images/" + user.getUserid() + ".jpg");
	    		MultipartFile image = user.getImage();
	            //Path path;
	            /*String path = request.getSession().getServletContext().getRealPath("/resources/images/"+user.getUserId()+".jpg");
	            System.out.println("Path="+path);
	            System.out.println("File name = " + user.getImage().getOriginalFilename());
	          
	            if(image!=null && !image.isEmpty())
	            {
	            	try
	            	{
	            		image.transferTo(new File(path.toString()));
	            		System.out.println("Image was saved  in:"+path.toString());
	            	}
	            	catch(Exception e)
	            	{
	            		e.printStackTrace();
	            		System.out.println("Image was not saved");
	            	}
	            }*/
	    	
	     	    
	    return "redirect:/CustomerLogin";
	
		
	}
	@ModelAttribute("user")
	public  User returnObject()
	{
		return new User();
	}
}
