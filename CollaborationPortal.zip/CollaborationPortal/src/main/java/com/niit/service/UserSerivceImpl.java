package com.niit.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.niit.dao.UserDao;
import com.niit.model.User;

@Service
public class UserSerivceImpl implements UserService {
	
	@Autowired
	private UserDao userdao;
	
	@Transactional
	public void setUserDao(UserDao userdao)
	{
		this.userdao=userdao;
	}

	@Transactional
	public void saveOrUpdate(User user) {
		// TODO Auto-generated method stub
		userdao.saveOrUpdate(user);
		
	}

	@Transactional
	public User getUserById(int userId) {
		// TODO Auto-generated method stub
		return userdao.getUserById(userId);
	}

	@Transactional
	public List<User> list() {
		// TODO Auto-generated method stub
		return userdao.list();
	}

	@Transactional
	public User getUserByname(String userName) {
		// TODO Auto-generated method stub
		return userdao.getUserByname(userName);
	}
	/*@Transactional
	public boolean  login(String username , String password)
	{
		return userdao.login(username, password);
	}*/

}
