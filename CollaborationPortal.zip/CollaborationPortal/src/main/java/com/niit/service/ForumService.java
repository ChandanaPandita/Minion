package com.niit.service;

import java.util.List;

import com.niit.model.Forum;

public interface ForumService {
	
	public void createNewForum(Forum f);
	public List<Forum> getForumList(String userName);
	public void delete(int forumId);
	public List<Forum> getForum();

}
