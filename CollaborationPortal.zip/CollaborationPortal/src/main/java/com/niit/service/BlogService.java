package com.niit.service;

import java.util.List;

import com.niit.model.Blog;

public interface BlogService {

	public void createNewBlog(Blog blog);
	public List<Blog> getBlogList(String blogUserName);
	public Blog getBlogById(int blogId);
	public Blog getBlogByName(String blogName);
	public List<Blog> getBlog();
}
