package com.niit.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Transient;

import org.hibernate.validator.constraints.NotEmpty;
import org.springframework.web.multipart.MultipartFile;

@Entity
public class User {
	@Id@GeneratedValue
 private int userId;
	
	@NotEmpty(message="Username should not be empty")
 private String userName;
	
	@NotEmpty(message="password should not be empty")
 private String password;
	
	@NotEmpty(message="Name should not be empty")
 private String name;
	@NotEmpty(message="emailId should not be empty")
 private String emailId;
	@NotEmpty(message="location should not be empty")
 private String location;
 private String role;
 private boolean isEnabled;
 @Transient
 private MultipartFile image;
public int getUserId() {
	return userId;
}
public void setUserId(int userId) {
	this.userId = userId;
}
public String getUserName() {
	return userName;
}
public void setUserName(String userName) {
	this.userName = userName;
}
public String getPassword() {
	return password;
}
public void setPassword(String password) {
	this.password = password;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getEmailId() {
	return emailId;
}
public void setEmailId(String emailId) {
	this.emailId = emailId;
}
public String getLocation() {
	return location;
}
public void setLocation(String location) {
	this.location = location;
}
public String getRole() {
	return role;
}
public void setRole(String role) {
	this.role = role;
}
public boolean isEnabled() {
	return isEnabled;
}
public void setEnabled(boolean isEnabled) {
	this.isEnabled = isEnabled;
}
public MultipartFile getImage() {
	return image;
}
public void setImage(MultipartFile image) {
	this.image = image;
} 

}

