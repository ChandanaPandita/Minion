package com.mychoice.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Transient;

import org.hibernate.validator.constraints.NotEmpty;
import org.springframework.web.multipart.MultipartFile;

@Entity
public class Item {
    @Id@GeneratedValue
	private int Id;

    @NotEmpty (message="Cannot be Empty")
	private String itemName;
    
    @NotEmpty (message="Cannot be Empty")
	private String description;
    
    private String category;
   	private double price;
	
    @Transient
	private MultipartFile file;
	
	public MultipartFile getMfile() {
		return file;
	}
	public void setMfile(MultipartFile mfile) {
		this.file = mfile;
	}
	
	public int getId() {
		return Id;
	}
	public void setId(int id) {
		Id = id;
	}
	public String getItemName() {
		return itemName;
	}
	public void setItemName(String itemName) {
		this.itemName = itemName;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}

}
