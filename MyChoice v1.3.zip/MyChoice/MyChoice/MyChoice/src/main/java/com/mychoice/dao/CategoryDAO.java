package com.mychoice.dao;

import com.mychoice.model.Item;

public interface CategoryDAO {
	void addItem(Item item);
	Item getItemByCategory(String category);

}
