package com.mychoice.service;


import java.util.List;

import com.mychoice.model.UserModel;

public interface UserService {

		public void addUserModel(UserModel user);
		public List<UserModel> viewUsers();
}
