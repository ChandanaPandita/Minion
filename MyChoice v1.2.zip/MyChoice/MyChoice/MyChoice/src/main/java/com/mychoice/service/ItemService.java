package com.mychoice.service;

import java.util.List;

import com.mychoice.model.Item;

public interface ItemService {
	public void addItem(Item item);
	public List<Item> viewItems ();
	void deleteItem(int id);
	Item getItemById(int id);
	void updateItem(Item item);

}
