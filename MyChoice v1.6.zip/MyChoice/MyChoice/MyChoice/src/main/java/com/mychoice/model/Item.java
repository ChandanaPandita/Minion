package com.mychoice.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Transient;

import org.hibernate.validator.constraints.NotEmpty;
import org.springframework.web.multipart.MultipartFile;

@Entity
public class Item {
    @Id@GeneratedValue
	private int id;

    @NotEmpty (message="Cannot be Empty")
	private String itemName;
    
    @NotEmpty (message="Cannot be Empty")
	private String description;
    
    @NotEmpty (message="Cannot be Empty")
    private String category;
   	private double price;
	
    @Transient
	MultipartFile File;
	
	public MultipartFile getFile() {
		return File;
	}
	public void setMfile(MultipartFile file) {
		File = file;
	}
	
	public int getid() {
		return id;
	}
	public void setid(int Id) {
		id = Id;
	}
	public String getItemName() {
		return itemName;
	}
	public void setItemName(String itemName) {
		this.itemName = itemName;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}

}
