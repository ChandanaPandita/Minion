package com.mychoice.controller;

import java.io.IOException;
import java.util.List;

import org.codehaus.jackson.JsonGenerationException;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.mychoice.model.Item;
import com.mychoice.model.UserModel;
import com.mychoice.service.UserService;
@Controller
public class AdminController {
	@Autowired
	UserService service;
	@RequestMapping("/viewController")
	public ModelAndView viewCustomer() throws JsonGenerationException, JsonMappingException,IOException
	{
		List<UserModel> list=service.viewUsers();
		System.out.println("View list"+list);
		ObjectMapper mapper=new ObjectMapper();
		String listJSON=mapper.writeValueAsString(list);
		return new ModelAndView("viewCustomer","listofcustomers",listJSON);
		
	}
	@RequestMapping("/addItem")
	public ModelAndView addItem()
	{
		Item item=new Item();
		return new ModelAndView("item","item",item);
		
	}
}